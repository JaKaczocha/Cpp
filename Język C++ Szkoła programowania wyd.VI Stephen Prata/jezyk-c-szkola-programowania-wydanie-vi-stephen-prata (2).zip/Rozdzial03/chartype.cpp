// chartype.cpp -- typ char
#include <iostream>
int main( )
{
    using namespace std;
    char ch;        // deklaracja zmiennej typu char

    cout << "Podaj znak: " << endl;
    cin >> ch;
    cout << "Hola! ";
    cout << "Dziękuję za znak " << ch << "." << endl;
    return 0;
}
