// myfirst.cpp--wyświetla komunikat

#include <iostream>                           // dyrektywa PREPROCESORA
int main()                                    // nagłówek funkcji
{                                             // początek treści funkcji
    using namespace std;                      // uwidocznienie definicji
    cout << "Zabaw się językiem C++.";        // komunikat
    cout << endl;                             // zaczynamy nowy wiersz
    cout << "Nie pożałujesz!" << endl;        // kolejny komunikat
    return 0;                                 // zakończenie działania funkcji main()
}                                             // koniec treści funkcji
