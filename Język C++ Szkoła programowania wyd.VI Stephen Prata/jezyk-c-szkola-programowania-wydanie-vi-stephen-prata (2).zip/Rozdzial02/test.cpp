#include <iostream>
     int
main
() {   using
    namespace
         std; cout
            <<
"Zabaw się językiem C++."
;    cout <<
endl; cout <<
"Nie pożałujesz!" << 
endl;/*cin.get();*/return 0; }
