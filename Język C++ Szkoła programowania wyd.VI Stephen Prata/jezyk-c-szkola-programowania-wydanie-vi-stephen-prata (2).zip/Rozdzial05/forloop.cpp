// forloop.cpp -- pętla loop po raz pierwszy
#include <iostream>
int main()
{
    using namespace std;
    int i;  // utworzenie licznika
//   inicjalizacja; test; aktualizacja
    for (i = 0; i < 5; i++)
        cout << "C++ zna pętle.\n";
    cout << "C++ wie, kiedy przestać.\n";
    return 0;
}
